/**
 * pnm_tests.c
 * 
 * Ce fichier contient les tests unitaires de pnm.h
 * 
 * @author: Dumoulin Peissone S193957
 * @date: 16/03/21
 * @projet: INFO0030 Projet 2
 */
var verify_8h =
[
    [ "manage_comments", "verify_8h.html#a73824141663fc2775bfb9d9d6a481c3d", null ],
    [ "manage_format_input", "verify_8h.html#a365f11a35e9f401b19bc5b6c38970216", null ],
    [ "verify_output", "verify_8h.html#a03aa65c4057ddf00a4fb573051153c23", null ],
    [ "verify_password", "verify_8h.html#a29b39013346dfbaba1719828cb96697b", null ],
    [ "verify_seed", "verify_8h.html#afe6e1eefb37f0bac734de17be430be77", null ],
    [ "verify_tap", "verify_8h.html#abd6acd138185ce7a7bd883d564061036", null ]
];
var annotated_dup =
[
    [ "LFSR_t", "struct_l_f_s_r__t.html", "struct_l_f_s_r__t" ],
    [ "PNM_t", "struct_p_n_m__t.html", "struct_p_n_m__t" ]
];
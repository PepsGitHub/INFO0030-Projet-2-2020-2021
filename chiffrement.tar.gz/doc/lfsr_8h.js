var lfsr_8h =
[
    [ "LFSR", "lfsr_8h.html#ab2653896e6359801f55af4668a40eb6c", null ],
    [ "create_lfsr", "lfsr_8h.html#a822883bd6266b75bcfa1c0663965a490", null ],
    [ "destroy_lfsr", "lfsr_8h.html#a2f63f3b4fdecdcef5a13d78a1e3576ca", null ],
    [ "generate", "lfsr_8h.html#a6714e605043e06e6ffba35c20d51adb6", null ],
    [ "get_N", "lfsr_8h.html#a9c64ddc31431cf5384fbb08621c44cba", null ],
    [ "get_seed", "lfsr_8h.html#ab0a69f651dadb09e20b499889b5e2566", null ],
    [ "get_tap", "lfsr_8h.html#a7662ef82f01e8670a21003876e7748ff", null ],
    [ "initialize", "lfsr_8h.html#a737337968d0b8cde9452baa1dbcb4c42", null ],
    [ "operate", "lfsr_8h.html#a8a83dfdb002244657860f021f380bf0d", null ],
    [ "set_N", "lfsr_8h.html#ac775126a2fbb0d5d8a8799338ba4d957", null ],
    [ "set_seed", "lfsr_8h.html#afde3a962231d9c590aa1d161e61c115d", null ],
    [ "set_tap", "lfsr_8h.html#a5fe81a84eccbb8bcc3b854f997e8302c", null ],
    [ "string", "lfsr_8h.html#ac87881b1e1cc42aa4d12685571ac2996", null ]
];
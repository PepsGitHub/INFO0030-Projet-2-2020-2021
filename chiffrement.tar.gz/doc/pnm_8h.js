var pnm_8h =
[
    [ "PNM", "pnm_8h.html#a5685d2cc86af79912d0d3e882e9640fd", null ],
    [ "create_matrix", "pnm_8h.html#a38aa548069d6bb8934ec582a3dd6b979", null ],
    [ "create_pnm", "pnm_8h.html#a91083f36dd80ee24e36ff6b4d9bc4977", null ],
    [ "destroy", "pnm_8h.html#a58491419bac919cbdfabff82bc50cb96", null ],
    [ "get_columns", "pnm_8h.html#a23f9be656f9bcc4a4c0dda752cb5eec3", null ],
    [ "get_magicNumber", "pnm_8h.html#a2d40e244dbd127d675a5b8db00069feb", null ],
    [ "get_matrix", "pnm_8h.html#aee8f1aaa21399084f34445498e8a74a9", null ],
    [ "get_maxValuePixel", "pnm_8h.html#a1cb2d38b518c52783d84ec0c11836cad", null ],
    [ "get_rows", "pnm_8h.html#a901df4d5aeceb60611faf395f91232d5", null ],
    [ "load_matrix", "pnm_8h.html#a8f6d192c26830c8ca12d3bff7bb7ac97", null ],
    [ "load_pnm", "pnm_8h.html#adf533a1bc155f9ee83d90c5a1564468f", null ],
    [ "set_columns", "pnm_8h.html#aa550e7de30a9f8fcb6b5a1fa2b17040c", null ],
    [ "set_magicNumber", "pnm_8h.html#a7c0fcbb53244631b0a793f3b4718bd37", null ],
    [ "set_matrix", "pnm_8h.html#a6a75f4c97f46440dbb1d2784af3afb07", null ],
    [ "set_maxValuePixel", "pnm_8h.html#a4939531f112add0633d5d9feb5dc44d8", null ],
    [ "set_rows", "pnm_8h.html#a7408e95bed0f2d4104b27a7ba5d64142", null ],
    [ "write_matrix", "pnm_8h.html#aab3a3cf34a6d5b49dfcd9e6a72b33e26", null ],
    [ "write_pnm", "pnm_8h.html#af899a2931ee1eaa8ecb6a313710ff228", null ]
];
var searchData=
[
  ['magicnumber_48',['magicNumber',['../struct_p_n_m__t.html#abe21b26f9e15a0f1df0566d7af85f9d6',1,'PNM_t']]],
  ['magicnumberchar_49',['MAGICNUMBERCHAR',['../pnm_8c.html#a8261d2ea94ad27e72ad9517d17a75562',1,'pnm.c']]],
  ['main_50',['main',['../lfsr__tests_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;lfsr_tests.c'],['../main_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;main.c']]],
  ['main_2ec_51',['main.c',['../main_8c.html',1,'']]],
  ['manage_5fcomments_52',['manage_comments',['../verify_8c.html#a73824141663fc2775bfb9d9d6a481c3d',1,'manage_comments(FILE *fp):&#160;verify.c'],['../verify_8h.html#a73824141663fc2775bfb9d9d6a481c3d',1,'manage_comments(FILE *fp):&#160;verify.c']]],
  ['manage_5fformat_5finput_53',['manage_format_input',['../verify_8c.html#a365f11a35e9f401b19bc5b6c38970216',1,'manage_format_input(PNM *image, char *format, char *input):&#160;verify.c'],['../verify_8h.html#a365f11a35e9f401b19bc5b6c38970216',1,'manage_format_input(PNM *image, char *format, char *input):&#160;verify.c']]],
  ['matrix_54',['matrix',['../struct_p_n_m__t.html#a73ca737613917baa1df3977edea1370a',1,'PNM_t']]],
  ['max_5fvalue_5fpixel_5fcipher_55',['MAX_VALUE_PIXEL_CIPHER',['../main_8c.html#ada16a9e3ec8a13026b194da6e6aee360',1,'main.c']]],
  ['max_5fvalue_5fpixel_5fdecipher_56',['MAX_VALUE_PIXEL_DECIPHER',['../main_8c.html#a5244dfa36719829fd5ad560d0bb751fa',1,'main.c']]],
  ['maxvaluepixel_57',['maxValuePixel',['../struct_p_n_m__t.html#a103774c4f90366ecd7e154c088db980c',1,'PNM_t']]]
];

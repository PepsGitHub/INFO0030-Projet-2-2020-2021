var searchData=
[
  ['magicnumber_196',['magicNumber',['../struct_p_n_m__t.html#a81e76850e31c68f09775a12013822e63',1,'PNM_t']]],
  ['matrix_197',['matrix',['../struct_p_n_m__t.html#a9e08edd23c3a95049049c26e4a4c56f8',1,'PNM_t']]],
  ['maxvaluepixel_198',['maxValuePixel',['../struct_p_n_m__t.html#ac0bbe450a172eb385e6352136aa92c7f',1,'PNM_t']]]
];

var searchData=
[
  ['write_5fmatrix_85',['write_matrix',['../pnm_8h.html#aab3a3cf34a6d5b49dfcd9e6a72b33e26',1,'pnm.c']]],
  ['write_5fpnm_86',['write_pnm',['../pnm_8h.html#af899a2931ee1eaa8ecb6a313710ff228',1,'pnm.c']]]
];

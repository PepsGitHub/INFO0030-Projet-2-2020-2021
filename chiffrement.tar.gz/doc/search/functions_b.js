var searchData=
[
  ['test_5ffilter_198',['test_filter',['../seatest_8c.html#a5f4807eba673af73e63d699b362dec42',1,'test_filter(char *filter):&#160;seatest.c'],['../seatest_8h.html#a5f4807eba673af73e63d699b362dec42',1,'test_filter(char *filter):&#160;seatest.c']]],
  ['transform_199',['transform',['../cipher_8c.html#a23ea7df83daace44d2f4a1add283a3ca',1,'transform(PNM *image, char *seed, char *tap, unsigned k):&#160;cipher.c'],['../cipher_8h.html#a23ea7df83daace44d2f4a1add283a3ca',1,'transform(PNM *image, char *seed, char *tap, unsigned k):&#160;cipher.c']]]
];

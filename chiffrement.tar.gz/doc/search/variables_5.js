var searchData=
[
  ['tap_202',['tap',['../struct_l_f_s_r__t.html#aea20e92fa304ee7c9b3f1f8d016a2d21',1,'LFSR_t']]]
];

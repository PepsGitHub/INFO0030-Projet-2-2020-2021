var searchData=
[
  ['destroy_53',['destroy',['../pnm_8h.html#a58491419bac919cbdfabff82bc50cb96',1,'pnm.c']]],
  ['destroy_5flfsr_54',['destroy_lfsr',['../lfsr_8h.html#a2f63f3b4fdecdcef5a13d78a1e3576ca',1,'lfsr.c']]]
];

var searchData=
[
  ['generation_139',['generation',['../lfsr_8c.html#a6509c967ab492a4d57e6176033555e42',1,'generation(LFSR *lfsr, unsigned int k):&#160;lfsr.c'],['../lfsr_8h.html#a6509c967ab492a4d57e6176033555e42',1,'generation(LFSR *lfsr, unsigned int k):&#160;lfsr.c']]],
  ['get_5fcolumns_140',['get_columns',['../pnm_8c.html#a6c231b541988f7a230e6887da58d1cc3',1,'get_columns(PNM *image):&#160;pnm.c'],['../pnm_8h.html#a6c231b541988f7a230e6887da58d1cc3',1,'get_columns(PNM *image):&#160;pnm.c']]],
  ['get_5fmagicnumber_141',['get_magicNumber',['../pnm_8c.html#ac3aa71b6b58a6b0502369dce298c3ae6',1,'get_magicNumber(PNM *image):&#160;pnm.c'],['../pnm_8h.html#a2d40e244dbd127d675a5b8db00069feb',1,'get_magicNumber(PNM *image):&#160;pnm.c']]],
  ['get_5fmatrix_142',['get_matrix',['../pnm_8c.html#ae224d7ea825d8b1818d4366c2893fcd2',1,'get_matrix(PNM *image):&#160;pnm.c'],['../pnm_8h.html#a1bf2e80dece5ce23db1df1ea92d0baed',1,'get_matrix(PNM *image):&#160;pnm.c']]],
  ['get_5fmaxvaluepixel_143',['get_maxValuePixel',['../pnm_8c.html#aea42d066bbb35f9f831542eaff90de6b',1,'get_maxValuePixel(PNM *image):&#160;pnm.c'],['../pnm_8h.html#aea42d066bbb35f9f831542eaff90de6b',1,'get_maxValuePixel(PNM *image):&#160;pnm.c']]],
  ['get_5fn_144',['get_N',['../lfsr_8c.html#a9c64ddc31431cf5384fbb08621c44cba',1,'get_N(LFSR *lfsr):&#160;lfsr.c'],['../lfsr_8h.html#a9c64ddc31431cf5384fbb08621c44cba',1,'get_N(LFSR *lfsr):&#160;lfsr.c']]],
  ['get_5frows_145',['get_rows',['../pnm_8c.html#a723ba0582a7d85ef49ce5fb5b93de87f',1,'get_rows(PNM *image):&#160;pnm.c'],['../pnm_8h.html#a723ba0582a7d85ef49ce5fb5b93de87f',1,'get_rows(PNM *image):&#160;pnm.c']]],
  ['get_5fseed_146',['get_seed',['../lfsr_8c.html#aa6e67379090a7263e7d7c8a71fb19674',1,'get_seed(LFSR *lfsr):&#160;lfsr.c'],['../lfsr_8h.html#ab0a69f651dadb09e20b499889b5e2566',1,'get_seed(LFSR *lfsr):&#160;lfsr.c']]],
  ['get_5ftap_147',['get_tap',['../lfsr_8c.html#a7662ef82f01e8670a21003876e7748ff',1,'get_tap(LFSR *lfsr):&#160;lfsr.c'],['../lfsr_8h.html#a7662ef82f01e8670a21003876e7748ff',1,'get_tap(LFSR *lfsr):&#160;lfsr.c']]]
];

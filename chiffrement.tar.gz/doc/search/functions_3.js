var searchData=
[
  ['generate_55',['generate',['../lfsr_8h.html#a6714e605043e06e6ffba35c20d51adb6',1,'lfsr.c']]],
  ['get_5fcolumns_56',['get_columns',['../pnm_8h.html#a23f9be656f9bcc4a4c0dda752cb5eec3',1,'pnm.c']]],
  ['get_5fmagicnumber_57',['get_magicNumber',['../pnm_8h.html#a2d40e244dbd127d675a5b8db00069feb',1,'pnm.c']]],
  ['get_5fmatrix_58',['get_matrix',['../pnm_8h.html#aee8f1aaa21399084f34445498e8a74a9',1,'pnm.c']]],
  ['get_5fmaxvaluepixel_59',['get_maxValuePixel',['../pnm_8h.html#a1cb2d38b518c52783d84ec0c11836cad',1,'pnm.c']]],
  ['get_5fn_60',['get_N',['../lfsr_8h.html#a9c64ddc31431cf5384fbb08621c44cba',1,'lfsr.c']]],
  ['get_5frows_61',['get_rows',['../pnm_8h.html#a901df4d5aeceb60611faf395f91232d5',1,'pnm.c']]],
  ['get_5fseed_62',['get_seed',['../lfsr_8h.html#ab0a69f651dadb09e20b499889b5e2566',1,'lfsr.c']]],
  ['get_5ftap_63',['get_tap',['../lfsr_8h.html#a7662ef82f01e8670a21003876e7748ff',1,'lfsr.c']]]
];

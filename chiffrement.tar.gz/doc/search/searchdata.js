var indexSectionsWithContent =
{
  0: "bcdgilmopstvw",
  1: "lp",
  2: "clpv",
  3: "bcdgilmostvw",
  4: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Pages"
};


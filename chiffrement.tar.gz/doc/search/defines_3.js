var searchData=
[
  ['magicnumberchar_234',['MAGICNUMBERCHAR',['../pnm_8c.html#a8261d2ea94ad27e72ad9517d17a75562',1,'pnm.c']]],
  ['max_5fvalue_5fpixel_5fcipher_235',['MAX_VALUE_PIXEL_CIPHER',['../main_8c.html#ada16a9e3ec8a13026b194da6e6aee360',1,'main.c']]],
  ['max_5fvalue_5fpixel_5fdecipher_236',['MAX_VALUE_PIXEL_DECIPHER',['../main_8c.html#a5244dfa36719829fd5ad560d0bb751fa',1,'main.c']]]
];

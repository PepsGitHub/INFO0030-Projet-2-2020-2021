var searchData=
[
  ['load_5fmatrix_149',['load_matrix',['../pnm_8c.html#a8f6d192c26830c8ca12d3bff7bb7ac97',1,'load_matrix(PNM *image, FILE *fp):&#160;pnm.c'],['../pnm_8h.html#a8f6d192c26830c8ca12d3bff7bb7ac97',1,'load_matrix(PNM *image, FILE *fp):&#160;pnm.c']]],
  ['load_5fpnm_150',['load_pnm',['../pnm_8c.html#adf533a1bc155f9ee83d90c5a1564468f',1,'load_pnm(PNM **image, char *filename):&#160;pnm.c'],['../pnm_8h.html#adf533a1bc155f9ee83d90c5a1564468f',1,'load_pnm(PNM **image, char *filename):&#160;pnm.c']]]
];

var searchData=
[
  ['initialize_158',['initialize',['../lfsr_8c.html#a930f85adac4594978553333e21bb9b4a',1,'initialize(char *seed, unsigned int tap):&#160;lfsr.c'],['../lfsr_8h.html#a737337968d0b8cde9452baa1dbcb4c42',1,'initialize(char *seed, unsigned int tap):&#160;lfsr.c']]],
  ['initialize_5fpassword_159',['initialize_password',['../cipher_8c.html#a410fff01da31634b5e3d07646322e6b5',1,'initialize_password(char *password, char *passwordBinary):&#160;cipher.c'],['../cipher_8h.html#a361bb3a6e751e82c7b70344b6137e7e1',1,'initialize_password(char *password, char *passwordBinary):&#160;cipher.c']]]
];

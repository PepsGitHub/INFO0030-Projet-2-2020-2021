var searchData=
[
  ['write_5fmatrix_122',['write_matrix',['../pnm_8c.html#aab3a3cf34a6d5b49dfcd9e6a72b33e26',1,'write_matrix(PNM *image, FILE *fp):&#160;pnm.c'],['../pnm_8h.html#aab3a3cf34a6d5b49dfcd9e6a72b33e26',1,'write_matrix(PNM *image, FILE *fp):&#160;pnm.c']]],
  ['write_5fpnm_123',['write_pnm',['../pnm_8c.html#af899a2931ee1eaa8ecb6a313710ff228',1,'write_pnm(PNM *image, char *filename):&#160;pnm.c'],['../pnm_8h.html#af899a2931ee1eaa8ecb6a313710ff228',1,'write_pnm(PNM *image, char *filename):&#160;pnm.c']]]
];

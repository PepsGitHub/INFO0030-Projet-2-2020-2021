var searchData=
[
  ['create_5flfsr_141',['create_lfsr',['../lfsr_8c.html#a822883bd6266b75bcfa1c0663965a490',1,'create_lfsr(unsigned int N, char *seed, unsigned int tap):&#160;lfsr.c'],['../lfsr_8h.html#a822883bd6266b75bcfa1c0663965a490',1,'create_lfsr(unsigned int N, char *seed, unsigned int tap):&#160;lfsr.c']]],
  ['create_5fmatrix_142',['create_matrix',['../pnm_8c.html#a38aa548069d6bb8934ec582a3dd6b979',1,'create_matrix(PNM *image):&#160;pnm.c'],['../pnm_8h.html#a38aa548069d6bb8934ec582a3dd6b979',1,'create_matrix(PNM *image):&#160;pnm.c']]],
  ['create_5fpnm_143',['create_pnm',['../pnm_8c.html#adcc22d38f5da82820d75a715227e0331',1,'create_pnm():&#160;pnm.c'],['../pnm_8h.html#a91083f36dd80ee24e36ff6b4d9bc4977',1,'create_pnm(void):&#160;pnm.c']]]
];

var searchData=
[
  ['lfsr_37',['LFSR',['../lfsr_8h.html#ab2653896e6359801f55af4668a40eb6c',1,'lfsr.h']]],
  ['lfsr_2ec_38',['lfsr.c',['../lfsr_8c.html',1,'']]],
  ['lfsr_2eh_39',['lfsr.h',['../lfsr_8h.html',1,'']]],
  ['lfsr_5ft_40',['LFSR_t',['../struct_l_f_s_r__t.html',1,'']]],
  ['lfsr_5ftests_2ec_41',['lfsr_tests.c',['../lfsr__tests_8c.html',1,'']]],
  ['load_5fmatrix_42',['load_matrix',['../pnm_8c.html#a8f6d192c26830c8ca12d3bff7bb7ac97',1,'load_matrix(PNM *image, FILE *fp):&#160;pnm.c'],['../pnm_8h.html#a8f6d192c26830c8ca12d3bff7bb7ac97',1,'load_matrix(PNM *image, FILE *fp):&#160;pnm.c']]],
  ['load_5fpnm_43',['load_pnm',['../pnm_8c.html#adf533a1bc155f9ee83d90c5a1564468f',1,'load_pnm(PNM **image, char *filename):&#160;pnm.c'],['../pnm_8h.html#adf533a1bc155f9ee83d90c5a1564468f',1,'load_pnm(PNM **image, char *filename):&#160;pnm.c']]]
];

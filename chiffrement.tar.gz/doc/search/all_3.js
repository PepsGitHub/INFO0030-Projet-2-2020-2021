var searchData=
[
  ['destroy_24',['destroy',['../pnm_8c.html#a58491419bac919cbdfabff82bc50cb96',1,'destroy(PNM *image, unsigned short allocation_value):&#160;pnm.c'],['../pnm_8h.html#a58491419bac919cbdfabff82bc50cb96',1,'destroy(PNM *image, unsigned short allocation_value):&#160;pnm.c']]],
  ['destroy_5flfsr_25',['destroy_lfsr',['../lfsr_8c.html#a2f63f3b4fdecdcef5a13d78a1e3576ca',1,'destroy_lfsr(LFSR *lfsr):&#160;lfsr.c'],['../lfsr_8h.html#a2f63f3b4fdecdcef5a13d78a1e3576ca',1,'destroy_lfsr(LFSR *lfsr):&#160;lfsr.c']]]
];

var searchData=
[
  ['main_162',['main',['../lfsr__tests_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;lfsr_tests.c'],['../main_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;main.c']]],
  ['manage_5fcomments_163',['manage_comments',['../verify_8c.html#a73824141663fc2775bfb9d9d6a481c3d',1,'manage_comments(FILE *fp):&#160;verify.c'],['../verify_8h.html#a73824141663fc2775bfb9d9d6a481c3d',1,'manage_comments(FILE *fp):&#160;verify.c']]],
  ['manage_5fformat_5finput_164',['manage_format_input',['../verify_8c.html#a365f11a35e9f401b19bc5b6c38970216',1,'manage_format_input(PNM *image, char *format, char *input):&#160;verify.c'],['../verify_8h.html#a365f11a35e9f401b19bc5b6c38970216',1,'manage_format_input(PNM *image, char *format, char *input):&#160;verify.c']]]
];

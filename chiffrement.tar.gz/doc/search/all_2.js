var searchData=
[
  ['destroy_22',['destroy',['../pnm_8c.html#a062b752e75e3d14f98214d2f3d7d4f06',1,'destroy(PNM *image, unsigned int allocation_value):&#160;pnm.c'],['../pnm_8h.html#a062b752e75e3d14f98214d2f3d7d4f06',1,'destroy(PNM *image, unsigned int allocation_value):&#160;pnm.c']]],
  ['destroy_5flfsr_23',['destroy_lfsr',['../lfsr_8c.html#a47c80404823d821fc198f8f6d3a540fd',1,'destroy_lfsr(LFSR *lfsr, unsigned int allocation_value):&#160;lfsr.c'],['../lfsr_8h.html#a47c80404823d821fc198f8f6d3a540fd',1,'destroy_lfsr(LFSR *lfsr, unsigned int allocation_value):&#160;lfsr.c']]]
];

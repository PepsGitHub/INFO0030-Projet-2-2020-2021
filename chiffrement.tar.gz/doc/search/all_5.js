var searchData=
[
  ['initialisation_36',['initialisation',['../lfsr_8c.html#a9b624ca59134a142ee4714edbfa9427e',1,'initialisation(char *seed, unsigned int tap):&#160;lfsr.c'],['../lfsr_8h.html#a79f21f3cdcb5abebff5eb41ba3aa3a48',1,'initialisation(char *seed, unsigned int tap):&#160;lfsr.c']]]
];

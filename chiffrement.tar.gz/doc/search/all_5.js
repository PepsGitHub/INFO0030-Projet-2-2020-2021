var searchData=
[
  ['generate_29',['generate',['../lfsr_8c.html#a6714e605043e06e6ffba35c20d51adb6',1,'generate(LFSR *lfsr, unsigned int k):&#160;lfsr.c'],['../lfsr_8h.html#a6714e605043e06e6ffba35c20d51adb6',1,'generate(LFSR *lfsr, unsigned int k):&#160;lfsr.c']]],
  ['get_5fcolumns_30',['get_columns',['../pnm_8c.html#a23f9be656f9bcc4a4c0dda752cb5eec3',1,'get_columns(PNM *image):&#160;pnm.c'],['../pnm_8h.html#a23f9be656f9bcc4a4c0dda752cb5eec3',1,'get_columns(PNM *image):&#160;pnm.c']]],
  ['get_5fmagicnumber_31',['get_magicNumber',['../pnm_8c.html#ac3aa71b6b58a6b0502369dce298c3ae6',1,'get_magicNumber(PNM *image):&#160;pnm.c'],['../pnm_8h.html#a2d40e244dbd127d675a5b8db00069feb',1,'get_magicNumber(PNM *image):&#160;pnm.c']]],
  ['get_5fmatrix_32',['get_matrix',['../pnm_8c.html#ab137fe4031b26cf6ddac6c8cacee82f3',1,'get_matrix(PNM *image):&#160;pnm.c'],['../pnm_8h.html#aee8f1aaa21399084f34445498e8a74a9',1,'get_matrix(PNM *image):&#160;pnm.c']]],
  ['get_5fmaxvaluepixel_33',['get_maxValuePixel',['../pnm_8c.html#a1cb2d38b518c52783d84ec0c11836cad',1,'get_maxValuePixel(PNM *image):&#160;pnm.c'],['../pnm_8h.html#a1cb2d38b518c52783d84ec0c11836cad',1,'get_maxValuePixel(PNM *image):&#160;pnm.c']]],
  ['get_5fn_34',['get_N',['../lfsr_8c.html#a9c64ddc31431cf5384fbb08621c44cba',1,'get_N(LFSR *lfsr):&#160;lfsr.c'],['../lfsr_8h.html#a9c64ddc31431cf5384fbb08621c44cba',1,'get_N(LFSR *lfsr):&#160;lfsr.c']]],
  ['get_5frows_35',['get_rows',['../pnm_8c.html#a901df4d5aeceb60611faf395f91232d5',1,'get_rows(PNM *image):&#160;pnm.c'],['../pnm_8h.html#a901df4d5aeceb60611faf395f91232d5',1,'get_rows(PNM *image):&#160;pnm.c']]],
  ['get_5fseed_36',['get_seed',['../lfsr_8c.html#aa6e67379090a7263e7d7c8a71fb19674',1,'get_seed(LFSR *lfsr):&#160;lfsr.c'],['../lfsr_8h.html#ab0a69f651dadb09e20b499889b5e2566',1,'get_seed(LFSR *lfsr):&#160;lfsr.c']]],
  ['get_5ftap_37',['get_tap',['../lfsr_8c.html#a7662ef82f01e8670a21003876e7748ff',1,'get_tap(LFSR *lfsr):&#160;lfsr.c'],['../lfsr_8h.html#a7662ef82f01e8670a21003876e7748ff',1,'get_tap(LFSR *lfsr):&#160;lfsr.c']]]
];

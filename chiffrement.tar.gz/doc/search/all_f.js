var searchData=
[
  ['verify_2ec_116',['verify.c',['../verify_8c.html',1,'']]],
  ['verify_2eh_117',['verify.h',['../verify_8h.html',1,'']]],
  ['verify_5foutput_118',['verify_output',['../verify_8c.html#a03aa65c4057ddf00a4fb573051153c23',1,'verify_output(char *output):&#160;verify.c'],['../verify_8h.html#a03aa65c4057ddf00a4fb573051153c23',1,'verify_output(char *output):&#160;verify.c']]],
  ['verify_5fpassword_119',['verify_password',['../verify_8c.html#a29b39013346dfbaba1719828cb96697b',1,'verify_password(char *password):&#160;verify.c'],['../verify_8h.html#a29b39013346dfbaba1719828cb96697b',1,'verify_password(char *password):&#160;verify.c']]],
  ['verify_5fseed_120',['verify_seed',['../verify_8c.html#aaf1d4776fd1ae9f187b9f904ae2fb2f8',1,'verify_seed(char *seed):&#160;verify.c'],['../verify_8h.html#afe6e1eefb37f0bac734de17be430be77',1,'verify_seed(char *seed):&#160;verify.c']]],
  ['verify_5ftap_121',['verify_tap',['../verify_8c.html#a3a00a6f6f0cd23a04c0786459d4c4896',1,'verify_tap(char *tap):&#160;verify.c'],['../verify_8h.html#abd6acd138185ce7a7bd883d564061036',1,'verify_tap(char *tap):&#160;verify.c']]]
];

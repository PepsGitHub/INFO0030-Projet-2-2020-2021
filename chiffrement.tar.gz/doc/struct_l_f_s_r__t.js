var struct_l_f_s_r__t =
[
    [ "N", "struct_l_f_s_r__t.html#ae8b170dcb376fe60270f4675f84e4477", null ],
    [ "seed", "struct_l_f_s_r__t.html#a82438bf6cdb8604ebdc23b74f91c18e5", null ],
    [ "tap", "struct_l_f_s_r__t.html#aea20e92fa304ee7c9b3f1f8d016a2d21", null ]
];
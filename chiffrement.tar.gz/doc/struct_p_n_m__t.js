var struct_p_n_m__t =
[
    [ "columns", "struct_p_n_m__t.html#acd85cd2d4e39c23ea2dabe5c88a49ac7", null ],
    [ "magicNumber", "struct_p_n_m__t.html#abe21b26f9e15a0f1df0566d7af85f9d6", null ],
    [ "matrix", "struct_p_n_m__t.html#a73ca737613917baa1df3977edea1370a", null ],
    [ "maxValuePixel", "struct_p_n_m__t.html#a103774c4f90366ecd7e154c088db980c", null ],
    [ "rows", "struct_p_n_m__t.html#a02031666663d218ef171aa32a24fd701", null ]
];